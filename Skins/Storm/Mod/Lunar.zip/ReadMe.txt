Mod "Lunar" by Aurel 12/03/2023

Mod For Water & Land Night Only
Use OpenPlanet to remove the "Warp" and "Clouds"

----------------------------------------------------------------------------------------

Base Files

Initial files come from the Mod "SM_Solo_modMonastere"
Mood.MoodSetting.xml come from the Maniaplanet documentation


----------------------------------------------------------------------------------------

Parameters changed on the file Mood.MoodSetting.xml

<AutoExp MinExposure="0" MaxExposure="0" to not get black to super bright bad effect

<LAmbient Color="bbccff" Scale="0.3"/> ambient will mapping before compute lightmaps

<LDirMoon Color="91a4ff" Scale="0.6"/> ambient after compute lightmaps, direct lights from the moon

<T3LightMap MaxHDR="7" BounceFactor="10" allows to have more lights from bounces behind blocks where there are no direct lights at all

<Atmo1 Power="20" Color="000000" Scale="0.105001"/> it removes the glow around the moon
<Atmo2 Power="2" Color="000000" Scale="0.0481005"/> it removes the glow around the moon

<HdrNorm_to_Intens> for the bloom section, to have black at black area, key 1 & 2, then a high value of bloom, key 3, and a solt bloom at high luminosity area for the rest of keys
        <Key In="0" Out="0"/>
	<Key In="0.25" Out="0"/>
	<Key In="0.40" Out="5"/>
        <Key In="2" Out="0.25"/>
        <Key In="6" Out="0.45"/>
        <Key In="64" Out="0.001"/>
</HdrNorm_to_Intens>