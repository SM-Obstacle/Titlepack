Mod "Lunar" by Aurel, version 14/11/2023
First release 12/03/2023
Update the 03/07/2023 (put black clouds and warp, fog disable better for people not using OpenPlanet)
Update the 20/11/2023 (Change SkyColor / Warp to blue, SkyClouds invisible / Improve ambient lights)

Mod For Water & Land Night Only
Use OpenPlanet to remove the "Warp" and "Clouds" and "SkyDome"
Use Land Night if you want to be able to remove everything around for a Space environment, Water land do not allow it

----------------------------------------------------------------------------------------

Base Files

Initial files come from the Mod "SM_Solo_modMonastere"
Mood.MoodSetting.xml come from the Maniaplanet documentation


----------------------------------------------------------------------------------------

Parameters changed on the file Mood.MoodSetting.xml

<AutoExp MinExposure="0" MaxExposure="0" to not get black to super bright bad effect

<LAmbient Color="bbccff" Scale="0.6"/> ambient will mapping before compute lightmaps

<LDirMoon Color="91a4ff" Scale="0.3"/> ambient after compute lightmaps, direct lights from the moon

<Atmo1 Power="20" Color="000000" Scale="0.105001"/> it removes the glow around the moon
<Atmo2 Power="2" Color="000000" Scale="0.0481005"/> it removes the glow around the moon

<Fog Enabled="0" it removes the Fog, still activable with the mediatracker

<HdrNorm_to_Intens> for the bloom section, to have black at black area, key 1 & 2, then a high value of bloom, key 3, and a solt bloom at high luminosity area for the rest of keys
        <Key In="0" Out="0"/>
	<Key In="0.25" Out="0"/>
	<Key In="0.40" Out="5"/>
        <Key In="2" Out="0.25"/>
        <Key In="6" Out="0.45"/>
        <Key In="64" Out="0.001"/>
</HdrNorm_to_Intens>


----------------------------------------------------------------------------------------

DecalsImage Folder

Decals3D_D & Decals3DTemp_D are transparent to be removed of the ground


----------------------------------------------------------------------------------------

Image Folder

AnimFire_D has been edited to blue
Lights_D & Lights_I the fire has been edited to blue
Warp_D has been edited to blue (same color than SkyColor)
WarpGWeight (same color than SkyColor)


----------------------------------------------------------------------------------------

MoodsLand & Water Folder

EnvCubicHdr has been edited
Fresnel is the vanilla night one
Moon has been edited
SkyClouds has been edited, alpha channel transparent to remove clouds (size scaled for a 32x32 pixels)
SkyColor has been edited to blue (no size optimization possible, otherwise it generated a bad rendering)
WaterColor has been edited to fading depth black to blue, alpha channel also edited